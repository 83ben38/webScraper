import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Deleter {
    public static void main(String[] args) throws FileNotFoundException {
        String s = "./src/output";
        File f = new File(s);
        ArrayList<String> files = new ArrayList<>();
        File[] t = f.listFiles();
        for (int i = 0; i < t.length; i++) {
            File[] z = t[i].listFiles();
            for (int j = 0; j < z.length; j++) {
                File x = z[j];
                if (x.isDirectory()){
                    File[] y = x.listFiles();
                    for (int k = 0; k < y.length; k++) {
                        x = y[k];
                        if (x.exists()) {
                            Scanner sc = new Scanner(x);
                            String str = sc.nextLine();
                            if (files.contains(str) || str.length() < 10) {
                                x.delete();
                                System.out.println("Deleting file");
                            } else {
                                files.add(str);
                            }
                        }
                    }
                }
                else if (x.exists()) {
                    Scanner sc = new Scanner(x);
                    String str = sc.nextLine();
                    if (files.contains(str) || str.length() < 10) {
                        x.delete();
                        System.out.println("Deleting file");
                    } else {
                        files.add(str);
                    }
                }
            }
        }
    }
}
