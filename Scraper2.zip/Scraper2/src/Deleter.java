import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Deleter {
    static ArrayList<String> files = new ArrayList<>();
    public static void main(String[] args) throws FileNotFoundException {
        String s = "./src/output";
        File f = new File(s);
        File[] t = f.listFiles();
        for (int i = 0; i < t.length; i++) {
            scrape(t[i]);
        }
    }
    public static void scrape(File t) throws FileNotFoundException {
        if (t.isDirectory()){
            File[] z = t.listFiles();
            for (int i = 0; i < z.length; i++) {
                scrape(z[i]);
            }
            return;
        }
        Scanner sc = new Scanner(t);
        if (sc.hasNextLine()){
            String st = sc.nextLine();
            if (files.contains(st)){
                t.delete();
            }
            else{
                files.add(st);
            }
        }
        else{
            t.delete();
        }
    }
}
