import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class Main {

    private static final String INPUT_FILE = "src/links.txt";
    private static final String OUTPUT_DIR = "src/output";
    private static String finalUrl;
    private static final int MAX_DEPTH = 500; // Adjust the depth level to control how deep the scraper should go

    private static final Set<String> visitedLinks = new HashSet<>();
    private static final Queue<String> pendingLinks = new ConcurrentLinkedQueue<>();
    private static final ReentrantLock lock = new ReentrantLock();

    public static void main(String[] args) throws FileNotFoundException {
        // Ensure the output directory exists
        File outputDir = new File(OUTPUT_DIR);
        if (!outputDir.exists()) {
            outputDir.mkdir();
        }


        // Read initial links from file and add them to the queue
        Scanner sc = new Scanner(new File("src/links.txt"));
            while (sc.hasNextLine()) {
                finalUrl = sc.nextLine();
                pendingLinks.add(finalUrl);
                int depth = 0;
                while (!pendingLinks.isEmpty()){
                    String nextUrl = pendingLinks.poll();
                    if (nextUrl != null && !visitedLinks.contains(nextUrl)) {
                        visitedLinks.add(nextUrl);
                        processPage(nextUrl, depth++);
                    }
                }
            }


        // Start scraping process




        // Optionally, save the list of visited links to a file
        try (PrintWriter pw = new PrintWriter(new FileWriter("src/visited_links.txt"))) {
            for (String link : visitedLinks) {
                pw.println(link);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processPage(String url, int depth) {
        if (!url.startsWith(finalUrl)){
            return;
        }
        if (url.contains("#")){
            return;
        }
        if (depth > MAX_DEPTH) {
            return; // Stop if max depth is exceeded
        }

        try {
            // Scrape the main page
            Document doc = Jsoup.connect(url).get();
            Elements el = doc.select("body");
            String pageContent = el.text();
            pageContent = url + "\n" + pageContent;

            String output = OUTPUT_DIR + "/" + finalUrl.replaceAll("[^a-zA-Z0-9]", "_");
            File f = new File(output);
            f.mkdirs();
            String fileName = url.substring(finalUrl.length()).replaceAll("[^a-zA-Z0-9]", "_") + "a.txt";
            File file;
            file = new File(output, fileName);
            try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
                pw.write(pageContent);
            }
            System.out.println("Scraped and saved: " + url);

            // Extract new links from the page
            Elements links = doc.select("a[href]");
            for (Element link : links) {
                String absHref = link.attr("abs:href");
                if (!visitedLinks.contains(absHref) && !pendingLinks.contains(absHref)) {
                    lock.lock();
                    try {
                        if (!visitedLinks.contains(absHref) && !pendingLinks.contains(absHref)) {
                            pendingLinks.add(absHref);
                        }
                    } finally {
                        lock.unlock();
                    }
                }
            }

            // Process new links in parallel


        } catch (IOException e) {
            System.err.println("Failed to scrape " + url + ": " + e.getMessage());
        }
    }
}
