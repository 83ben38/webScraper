import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class Main {

    private static final String INPUT_FILE = "src/links.txt";
    private static final String OUTPUT_DIR = "src/output";
    private static String finalUrl;
    private static final int MAX_DEPTH = 50; // Adjust the depth level to control how deep the scraper should go

    private static final Set<String> visitedLinks = new HashSet<>();
    private static final Queue<String> pendingLinks = new ConcurrentLinkedQueue<>();
    private static final ReentrantLock lock = new ReentrantLock();

    public static void main(String[] args) {
        // Ensure the output directory exists
        File outputDir = new File(OUTPUT_DIR);
        if (!outputDir.exists()) {
            outputDir.mkdir();
        }

        ExecutorService executor = Executors.newFixedThreadPool(10); // Adjust pool size as needed

        // Read initial links from file and add them to the queue
        try (BufferedReader br = new BufferedReader(new FileReader(INPUT_FILE))) {
            String url;
            while ((url = br.readLine()) != null) {
                finalUrl = url.trim();
                if (!finalUrl.isEmpty() && !visitedLinks.contains(finalUrl)) {
                    pendingLinks.add(finalUrl);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Start scraping process
        while (!pendingLinks.isEmpty()) {
            String url = pendingLinks.poll();
            if (url != null && !visitedLinks.contains(url)) {
                visitedLinks.add(url);
                executor.submit(() -> processPage(url, 0));
            }
        }

        executor.shutdown();
        while (!executor.isTerminated()) {
            // Wait for all tasks to finish
        }

        // Optionally, save the list of visited links to a file
        try (PrintWriter pw = new PrintWriter(new FileWriter("src/visited_links.txt"))) {
            for (String link : visitedLinks) {
                pw.println(link);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void processPage(String url, int depth) {
        if (!url.startsWith(finalUrl)){
            return;
        }
        if (depth > MAX_DEPTH) {
            return; // Stop if max depth is exceeded
        }

        try {
            // Scrape the main page
            Document doc = Jsoup.connect(url).get();
            Elements el = doc.select("article.primaryArea");
            String pageContent = el.text();


            String output = OUTPUT_DIR + "/" + finalUrl.replaceAll("[^a-zA-Z0-9]", "_");
            File f = new File(output);
            f.mkdirs();
            String fileName = url.substring(finalUrl.length()).replaceAll("[^a-zA-Z0-9]", "_") + "a.txt";
            File file;
            file = new File(output, fileName);
            try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
                pw.write(pageContent);
            }
            System.out.println("Scraped and saved: " + url);

            // Extract new links from the page
            Elements links = doc.select("a[href]");
            for (Element link : links) {
                String absHref = link.attr("abs:href");
                if (!visitedLinks.contains(absHref) && !pendingLinks.contains(absHref)) {
                    lock.lock();
                    try {
                        if (!visitedLinks.contains(absHref) && !pendingLinks.contains(absHref)) {
                            pendingLinks.add(absHref);
                        }
                    } finally {
                        lock.unlock();
                    }
                }
            }

            // Process new links in parallel
            while (!pendingLinks.isEmpty()) {
                String nextUrl = pendingLinks.poll();
                if (nextUrl != null && !visitedLinks.contains(nextUrl)) {
                    visitedLinks.add(nextUrl);
                    if (depth + 1 <= MAX_DEPTH) { // Ensure we respect the depth limit
                        processPage(nextUrl, depth + 1);
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Failed to scrape " + url + ": " + e.getMessage());
        }
    }
}
